import React from 'react'
import PublicBanners from '../components/PublicBanners'

const page = () => {
  return (
    <div>
        <PublicBanners title='News Page' message='to be done...' />   
    </div>
  )
}

export default page