import React from 'react'
import { TrainingBanner } from './_components/TrainingBanner'

const page = () => {
  return (
    <div className=' flex flex-col '>
        <TrainingBanner 
        bannerImage={''}
        description={''}
        title={''}
        />
    </div>
  )
}

export default page