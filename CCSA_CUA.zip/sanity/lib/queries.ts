import { groq } from "next-sanity";
import { client } from "./client";



export const revalidate = 60




