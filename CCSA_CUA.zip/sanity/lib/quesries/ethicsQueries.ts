
import { groq } from "next-sanity"
import { client } from "../client";
import { revalidate } from "../queries";

revalidate

